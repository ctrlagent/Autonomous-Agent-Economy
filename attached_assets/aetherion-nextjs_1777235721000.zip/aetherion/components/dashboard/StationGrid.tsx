'use client'
import { useState } from 'react'
import { ROOMS } from '@/lib/data'
import { Room } from '@/types'
import { RoomCard } from './RoomCard'
import { RoomDetail } from './RoomDetail'
import { ActivityLog } from './ActivityLog'

export function StationGrid() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)

  const handleRoomClick = (room: Room) => {
    setSelectedRoom(prev => prev?.id === room.id ? null : room)
  }

  return (
    <div className="grid grid-cols-[200px_1fr] gap-3 h-full">
      {/* Left: Activity Log */}
      <ActivityLog />

      {/* Right: Station + Room Detail */}
      <div className="flex flex-col gap-3">
        <div className="bg-ae-surface border border-ae-border rounded-lg p-3">
          <div className="text-[9px] font-mono tracking-widest text-ae-muted mb-3">SPACE STATION</div>
          <div className="grid grid-cols-3 gap-2">
            {ROOMS.map((room, i) => (
              <RoomCard
                key={room.id}
                room={room}
                selected={selectedRoom?.id === room.id}
                onClick={() => handleRoomClick(room)}
                index={i}
              />
            ))}
          </div>
        </div>

        <RoomDetail room={selectedRoom} />
      </div>
    </div>
  )
}
