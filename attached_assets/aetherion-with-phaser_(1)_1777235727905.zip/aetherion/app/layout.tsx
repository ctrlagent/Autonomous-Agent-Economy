import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'AETHERION — Autonomous Agent Economy',
  description: 'Agentic AI Operating System for building real businesses',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="ae-crt ae-grid-bg antialiased">{children}</body>
    </html>
  )
}
