interface BadgeProps {
  children: React.ReactNode
  variant?: 'cyan' | 'blue' | 'violet' | 'amber' | 'green' | 'red' | 'muted'
  className?: string
}

const variants = {
  cyan: 'bg-ae-cyan-dim text-ae-cyan border-ae-cyan/20',
  blue: 'bg-ae-blue-dim text-ae-blue border-ae-blue/20',
  violet: 'bg-ae-violet-dim text-ae-violet border-ae-violet/20',
  amber: 'bg-ae-amber-dim text-ae-amber border-ae-amber/20',
  green: 'bg-ae-green-dim text-ae-green border-ae-green/20',
  red: 'bg-ae-red-dim text-ae-red border-ae-red/20',
  muted: 'bg-ae-border text-ae-muted border-ae-border-bright',
}

export function Badge({ children, variant = 'muted', className = '' }: BadgeProps) {
  return (
    <span className={`
      inline-flex items-center px-2 py-0.5
      text-[10px] font-mono tracking-widest
      border rounded
      ${variants[variant]} ${className}
    `}>
      {children}
    </span>
  )
}
