'use client'
import { STATUS_BG } from '@/lib/data'

interface StatusDotProps {
  status: string
  size?: 'sm' | 'md'
}

export function StatusDot({ status, size = 'sm' }: StatusDotProps) {
  const sizeClass = size === 'sm' ? 'w-1.5 h-1.5' : 'w-2 h-2'
  const colorClass = STATUS_BG[status] || 'bg-ae-dim'
  const animClass = status === 'active' || status === 'Active' ? 'status-dot-active'
    : status === 'working' || status === 'Working' ? 'status-dot-working' : ''

  return (
    <span className={`inline-block rounded-full flex-shrink-0 ${sizeClass} ${colorClass} ${animClass}`} />
  )
}
