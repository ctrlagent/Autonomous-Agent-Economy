'use client'
import { motion } from 'framer-motion'

interface ProgressBarProps {
  value: number
  color?: 'blue' | 'cyan' | 'green' | 'amber' | 'violet'
  className?: string
  showLabel?: boolean
}

const barColors = {
  blue: 'bg-ae-blue',
  cyan: 'bg-ae-cyan',
  green: 'bg-ae-green',
  amber: 'bg-ae-amber',
  violet: 'bg-ae-violet',
}

export function ProgressBar({ value, color = 'blue', className = '', showLabel = false }: ProgressBarProps) {
  return (
    <div className={`${className}`}>
      <div className="h-0.5 bg-ae-border rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${barColors[color]}`}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 1.2, ease: [0.4, 0, 0.2, 1] }}
        />
      </div>
      {showLabel && (
        <span className="text-[9px] font-mono text-ae-muted mt-1 block">{value}%</span>
      )}
    </div>
  )
}
