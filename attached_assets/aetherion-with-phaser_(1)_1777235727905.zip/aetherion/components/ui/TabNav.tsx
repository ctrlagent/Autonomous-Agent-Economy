'use client'
import { motion } from 'framer-motion'
import { Tab } from '@/types'

interface TabNavProps {
  active: Tab
  onChange: (tab: Tab) => void
}

const TABS: { id: Tab; label: string }[] = [
  { id: 'station', label: 'Station' },
  { id: 'crew', label: 'Crew' },
  { id: 'missions', label: 'Missions' },
  { id: 'comms', label: 'Ship Comms' },
  { id: 'market', label: 'Market' },
]

export function TabNav({ active, onChange }: TabNavProps) {
  return (
    <div className="flex gap-1 flex-wrap">
      {TABS.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`
            relative px-3 py-1.5 text-[11px] font-mono tracking-wider
            border rounded transition-colors duration-150 cursor-pointer
            ${active === tab.id
              ? 'border-ae-blue/40 text-ae-text'
              : 'border-ae-border text-ae-muted hover:border-ae-border-bright hover:text-ae-text'
            }
          `}
        >
          {active === tab.id && (
            <motion.span
              layoutId="tab-bg"
              className="absolute inset-0 bg-ae-blue-dim rounded"
              transition={{ type: 'spring', bounce: 0.15, duration: 0.4 }}
            />
          )}
          <span className="relative z-10">{tab.label}</span>
        </button>
      ))}
    </div>
  )
}
