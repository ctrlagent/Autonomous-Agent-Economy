'use client'
import { motion } from 'framer-motion'
import { Room } from '@/types'
import { StatusDot } from '@/components/ui/StatusDot'
import { ProgressBar } from '@/components/ui/ProgressBar'

interface RoomCardProps {
  room: Room
  selected: boolean
  onClick: () => void
  index: number
}

export function RoomCard({ room, selected, onClick, index }: RoomCardProps) {
  const isActive = room.status !== 'idle'

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.06, duration: 0.4, ease: 'easeOut' }}
      whileHover={{ scale: 1.02, transition: { duration: 0.15 } }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative p-2.5 rounded-lg border cursor-pointer transition-all duration-200
        ${selected
          ? 'border-ae-blue/50 bg-ae-blue-dim ae-glow-blue'
          : isActive
            ? 'border-ae-border-bright bg-ae-surface hover:border-ae-blue/30'
            : 'border-ae-border bg-ae-surface/50 hover:border-ae-border-bright'
        }
      `}
    >
      {/* Corner accent for active rooms */}
      {isActive && (
        <div className="absolute top-0 right-0 w-6 h-6 overflow-hidden rounded-tr-lg">
          <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-ae-blue/20 to-transparent" />
        </div>
      )}

      <div className="flex justify-between items-start mb-2">
        <span className="text-base text-ae-muted">{room.icon}</span>
        <StatusDot status={room.status} />
      </div>

      <div className="text-[11px] font-semibold text-ae-text mb-0.5 leading-tight">{room.name}</div>
      <div className="text-[9px] font-mono text-ae-muted mb-2">×{room.agents} agents</div>

      {room.pct > 0 && (
        <ProgressBar
          value={room.pct}
          color={room.status === 'working' ? 'blue' : 'cyan'}
        />
      )}
    </motion.div>
  )
}
