'use client'
import dynamic from 'next/dynamic'
import { ActivityLog } from './ActivityLog'

const StationPhaser = dynamic(
  () => import('./StationPhaser').then(m => ({ default: m.StationPhaser })),
  {
    ssr: false,
    loading: () => (
      <div className="bg-ae-surface border border-ae-border rounded-lg flex items-center justify-center h-64">
        <span className="text-[10px] font-mono text-ae-dim tracking-widest animate-pulse">
          INITIALISING RENDERER...
        </span>
      </div>
    ),
  }
)

export function StationGrid() {
  return (
    <div className="grid grid-cols-[200px_1fr] gap-3">
      <ActivityLog />
      <StationPhaser />
    </div>
  )
}
