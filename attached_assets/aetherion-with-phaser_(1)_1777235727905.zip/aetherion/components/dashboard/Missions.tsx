'use client'
import { motion } from 'framer-motion'
import { MISSIONS } from '@/lib/data'
import { Badge } from '@/components/ui/Badge'
import { ProgressBar } from '@/components/ui/ProgressBar'

const rewardColors: ('green' | 'blue' | 'violet' | 'amber' | 'cyan')[] = ['green', 'blue', 'violet', 'amber']

export function Missions() {
  return (
    <div className="max-w-lg">
      <div className="bg-ae-surface border border-ae-border rounded-lg p-5">
        <div className="text-[9px] font-mono tracking-widest text-ae-muted mb-5">ACTIVE MISSIONS</div>

        <div className="space-y-5">
          {MISSIONS.map((mission, i) => {
            const pct = Math.round((mission.current / mission.target) * 100)
            const done = pct >= 100

            return (
              <motion.div
                key={mission.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08, duration: 0.4, ease: 'easeOut' }}
              >
                <div className="flex justify-between items-baseline mb-1.5">
                  <span className="text-[13px] font-semibold text-ae-text">{mission.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-ae-muted">
                      {mission.prefix}{mission.current.toLocaleString()} / {mission.prefix}{mission.target.toLocaleString()}
                    </span>
                    {done && <span className="text-ae-green text-[11px]">✓</span>}
                  </div>
                </div>

                <ProgressBar
                  value={Math.min(pct, 100)}
                  color={done ? 'green' : rewardColors[i % rewardColors.length]}
                  showLabel
                />
              </motion.div>
            )
          })}
        </div>

        <div className="border-t border-ae-border mt-6 pt-4">
          <div className="text-[9px] font-mono tracking-widest text-ae-muted mb-3">REWARDS</div>
          <div className="flex gap-2 flex-wrap">
            {MISSIONS.map((m, i) => (
              <Badge key={m.id} variant={rewardColors[i % rewardColors.length]}>
                {m.reward}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
