'use client'
import { motion } from 'framer-motion'
import { TEMPLATES } from '@/lib/data'
import { Badge } from '@/components/ui/Badge'

const categoryVariant: Record<string, 'cyan' | 'blue' | 'violet' | 'amber'> = {
  Crypto: 'amber',
  Content: 'cyan',
  'E-Commerce': 'green' as any,
  SaaS: 'violet',
}

export function Marketplace() {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="text-[9px] font-mono tracking-widest text-ae-muted">TEMPLATE MARKETPLACE</div>
        <div className="flex gap-2">
          <input
            placeholder="Search..."
            className="bg-ae-bg border border-ae-border rounded px-2.5 py-1
              text-[11px] font-mono text-ae-text placeholder-ae-dim
              focus:outline-none focus:border-ae-blue/40 transition-colors w-40"
          />
        </div>
      </div>

      <div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-3">
        {TEMPLATES.map((tmpl, i) => (
          <motion.div
            key={tmpl.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4, ease: 'easeOut' }}
            whileHover={{ y: -2, transition: { duration: 0.15 } }}
            className={`
              relative bg-ae-surface rounded-lg p-4 border transition-all duration-200
              ${tmpl.active
                ? 'border-ae-blue/40 ae-glow-blue'
                : 'border-ae-border hover:border-ae-border-bright'
              }
            `}
          >
            {tmpl.active && (
              <div className="absolute -top-2.5 left-3">
                <Badge variant="blue">ACTIVE</Badge>
              </div>
            )}

            <div className="mb-1 flex items-start justify-between gap-2">
              <div className="text-[13px] font-semibold text-ae-text leading-tight">{tmpl.name}</div>
              <Badge variant={categoryVariant[tmpl.category] || 'muted'}>{tmpl.category}</Badge>
            </div>

            <p className="text-[11px] text-ae-muted leading-relaxed mb-3">{tmpl.desc}</p>

            <div className="flex gap-3 text-[10px] font-mono text-ae-dim mb-3">
              <span>×{tmpl.agents} agents</span>
              <span>◫{tmpl.rooms} rooms</span>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] text-ae-amber">★{tmpl.rating}</span>
                <span className="text-[10px] text-ae-dim font-mono ml-1.5">{tmpl.users.toLocaleString()} users</span>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                className={`
                  px-3 py-1 text-[10px] font-mono rounded border transition-colors duration-150
                  ${tmpl.active
                    ? 'border-ae-blue/40 text-ae-blue hover:bg-ae-blue-dim'
                    : 'border-ae-border text-ae-muted hover:border-ae-border-bright hover:text-ae-text'
                  }
                `}
              >
                {tmpl.active ? 'Active' : 'Use template'}
              </motion.button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
