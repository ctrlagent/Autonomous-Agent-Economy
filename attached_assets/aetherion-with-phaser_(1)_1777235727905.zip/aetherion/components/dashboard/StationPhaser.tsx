'use client'
import { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import type { AgentSprite } from '@/lib/stationScene'
import { Badge } from '@/components/ui/Badge'
import { StatusDot } from '@/components/ui/StatusDot'
import { ProgressBar } from '@/components/ui/ProgressBar'

const ROOM_LABELS = [
  { id: 'r1', name: 'Research Lab',  icon: '◎', col: 0, row: 0 },
  { id: 'r2', name: 'Dev Lab',       icon: '⬡', col: 1, row: 0 },
  { id: 'r3', name: 'Design Studio', icon: '◈', col: 2, row: 0 },
  { id: 'r4', name: 'Marketing Hub', icon: '◉', col: 0, row: 1 },
  { id: 'r5', name: 'Ops Center',    icon: '⬢', col: 1, row: 1 },
  { id: 'r6', name: 'Analytics',     icon: '◆', col: 2, row: 1 },
]

const roleColors: Record<string, 'cyan' | 'blue' | 'violet' | 'amber' | 'green'> = {
  Research: 'cyan', Strategy: 'blue', Builder: 'amber',
  Design: 'violet', Growth: 'green', Analytics: 'blue',
}

export function StationPhaser() {
  const mountRef    = useRef<HTMLDivElement>(null)
  const gameRef     = useRef<import('phaser').Game | null>(null)
  const [selectedAgent, setSelectedAgent] = useState<AgentSprite | null>(null)
  const [ready, setReady] = useState(false)
  const [dims, setDims]   = useState({ w: 720, h: 360 })

  // measure container
  useEffect(() => {
    const el = mountRef.current
    if (!el) return
    const ro = new ResizeObserver(entries => {
      const { width } = entries[0].contentRect
      setDims({ w: Math.max(320, Math.floor(width)), h: Math.max(260, Math.floor(width * 0.5)) })
    })
    ro.observe(el)
    setDims({ w: Math.max(320, Math.floor(el.offsetWidth)), h: Math.max(260, Math.floor(el.offsetWidth * 0.5)) })
    return () => ro.disconnect()
  }, [])

  const handleAgentSelect = useCallback((agent: AgentSprite | null) => {
    setSelectedAgent(agent)
  }, [])

  // boot Phaser
  useEffect(() => {
    if (!mountRef.current || gameRef.current) return
    let game: import('phaser').Game

    const boot = async () => {
      const Phaser = (await import('phaser')).default
      const { StationScene } = await import('@/lib/stationScene')

      const scene = new StationScene()
      scene.onAgentSelect = handleAgentSelect

      game = new Phaser.Game({
        type: Phaser.AUTO,
        width: dims.w,
        height: dims.h,
        backgroundColor: '#0a0b0f',
        parent: mountRef.current!,
        scene,
        audio: { noAudio: true },
        render: {
          antialias: true,
          pixelArt: false,
          roundPixels: false,
          transparent: false,
        },
        // kill default banner
        banner: false,
      })

      gameRef.current = game
      setTimeout(() => setReady(true), 400)
    }

    boot()

    return () => {
      game?.destroy(true)
      gameRef.current = null
    }
    // intentionally run once
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // resize game when container changes
  useEffect(() => {
    if (!gameRef.current) return
    gameRef.current.scale.resize(dims.w, dims.h)
  }, [dims])

  return (
    <div className="flex flex-col gap-3">
      {/* Canvas wrapper */}
      <div className="bg-ae-surface border border-ae-border rounded-lg overflow-hidden relative">

        {/* HUD overlay — room name labels (rendered in DOM over canvas) */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ zIndex: 10 }}
        >
          {/* title bar */}
          <div className="absolute top-0 left-0 right-0 h-[38px] flex items-center px-4 gap-3">
            <span className="text-[10px] font-mono tracking-widest text-ae-muted">SPACE STATION</span>
            <span className="text-[9px] font-mono text-ae-blue/60">● LIVE</span>
            <span className="ml-auto text-[9px] font-mono text-ae-dim">
              8 AGENTS ONLINE
            </span>
          </div>

          {/* Room name labels — positioned to match Phaser room grid */}
          {ROOM_LABELS.map(r => (
            <RoomLabel key={r.id} room={r} canvasW={dims.w} canvasH={dims.h} />
          ))}
        </div>

        {/* Phaser mount */}
        <div
          ref={mountRef}
          className="w-full"
          style={{ height: dims.h, minHeight: 260 }}
        />

        {/* Loading overlay */}
        <AnimatePresence>
          {!ready && (
            <motion.div
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 bg-ae-bg flex items-center justify-center z-20"
            >
              <div className="flex flex-col items-center gap-3">
                <div className="flex gap-1.5">
                  {[0,1,2,3].map(i => (
                    <motion.div
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-ae-blue"
                      animate={{ opacity: [0.2, 1, 0.2] }}
                      transition={{ duration: 1.2, delay: i * 0.15, repeat: Infinity }}
                    />
                  ))}
                </div>
                <span className="text-[10px] font-mono text-ae-muted tracking-widest">
                  BOOTING STATION...
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Agent detail strip */}
      <AnimatePresence mode="wait">
        {selectedAgent ? (
          <motion.div
            key={selectedAgent.id}
            initial={{ opacity: 0, y: 8, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -4, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="bg-ae-surface border border-ae-blue/30 rounded-lg p-3 ae-glow-blue overflow-hidden"
          >
            <div className="flex items-center gap-3">
              {/* avatar */}
              <div className="w-8 h-8 rounded-full bg-ae-blue-dim border border-ae-blue/30
                flex items-center justify-center text-[11px] font-bold font-mono text-ae-blue flex-shrink-0">
                {selectedAgent.name.slice(0, 2).toUpperCase()}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-bold text-ae-text">{selectedAgent.name}</span>
                  <Badge variant={roleColors[selectedAgent.role] || 'blue'}>{selectedAgent.role}</Badge>
                  <div className="ml-auto flex items-center gap-1.5">
                    <StatusDot status={selectedAgent.status} />
                    <span className="text-[10px] font-mono text-ae-muted">{selectedAgent.status}</span>
                  </div>
                </div>

                {selectedAgent.pct > 0 && (
                  <ProgressBar
                    value={selectedAgent.pct}
                    color={roleColors[selectedAgent.role] || 'blue'}
                    showLabel
                  />
                )}
              </div>

              <button
                onClick={() => setSelectedAgent(null)}
                className="text-ae-dim hover:text-ae-muted transition-colors text-[11px] ml-2 flex-shrink-0"
              >
                ✕
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="hint"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-[10px] font-mono text-ae-dim text-center py-1"
          >
            Click an agent on the canvas to inspect
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── Room label overlay positioned proportionally over the canvas ──────────
function RoomLabel({
  room,
  canvasW,
  canvasH,
}: {
  room: typeof ROOM_LABELS[0]
  canvasW: number
  canvasH: number
}) {
  const padX = 20, padY = 48, gap = 8
  const cols = 3, rows = 2
  const rw = (canvasW - padX * 2 - gap * (cols - 1)) / cols
  const rh = (canvasH - padY * 2 - gap * (rows - 1)) / rows
  const x = padX + room.col * (rw + gap)
  const y = padY + room.row * (rh + gap)

  return (
    <div
      className="absolute flex items-center gap-1"
      style={{
        left: x + 8,
        top:  y + 7,
        width: rw - 16,
      }}
    >
      <span className="text-[11px] text-ae-muted/60">{room.icon}</span>
      <span className="text-[10px] font-mono text-ae-muted/80 truncate">{room.name}</span>
    </div>
  )
}
