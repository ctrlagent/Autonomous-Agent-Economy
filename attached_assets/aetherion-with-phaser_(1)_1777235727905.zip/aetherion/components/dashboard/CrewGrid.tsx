'use client'
import { useState } from 'react'
import { AGENTS } from '@/lib/data'
import { AgentCard } from './AgentCard'
import { AgentDetail } from './AgentDetail'

export function CrewGrid() {
  const [selectedIdx, setSelectedIdx] = useState(0)

  return (
    <div className="grid grid-cols-[1fr_240px] gap-3">
      <div className="grid grid-cols-[repeat(auto-fill,minmax(130px,1fr))] gap-2 content-start">
        {AGENTS.map((agent, i) => (
          <AgentCard
            key={agent.id}
            agent={agent}
            selected={selectedIdx === i}
            onClick={() => setSelectedIdx(i)}
            index={i}
          />
        ))}
      </div>
      <AgentDetail agent={AGENTS[selectedIdx]} />
    </div>
  )
}
