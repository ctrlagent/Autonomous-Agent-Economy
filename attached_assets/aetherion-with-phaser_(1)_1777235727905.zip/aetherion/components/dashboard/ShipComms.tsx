'use client'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CommMessage } from '@/types'
import { COMMS } from '@/lib/data'
import { Badge } from '@/components/ui/Badge'

const actionVariant: Record<string, 'green' | 'amber' | 'cyan'> = {
  approve: 'green',
  review: 'amber',
  optimize: 'cyan',
}

export function ShipComms() {
  const [messages, setMessages] = useState<CommMessage[]>(COMMS)
  const [allApproved, setAllApproved] = useState(false)

  const approveMessage = (id: string) => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, approved: true } : m))
  }

  const approveAll = () => {
    setMessages(prev => prev.map(m => ({ ...m, approved: true })))
    setAllApproved(true)
    setTimeout(() => setAllApproved(false), 3000)
  }

  return (
    <div className="max-w-lg">
      <div className="bg-ae-surface border border-ae-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="text-[9px] font-mono tracking-widest text-ae-muted">SHIP COMMS</div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-ae-green status-dot-active" />
            <span className="text-[9px] font-mono text-ae-green/70">4 messages</span>
          </div>
        </div>

        <div className="space-y-2 mb-4">
          <AnimatePresence>
            {allApproved && (
              <motion.div
                initial={{ opacity: 0, y: -8, height: 0 }}
                animate={{ opacity: 1, y: 0, height: 'auto' }}
                exit={{ opacity: 0, y: -4, height: 0 }}
                className="bg-ae-green-dim border border-ae-green/20 rounded-lg px-3 py-2
                  text-[12px] text-ae-green mb-2"
              >
                ✓ All tasks approved — agents resuming execution...
              </motion.div>
            )}
          </AnimatePresence>

          {messages.map((msg, i) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07, duration: 0.3 }}
              className={`
                bg-ae-bg border rounded-lg p-3 transition-colors duration-300
                ${msg.approved ? 'border-ae-green/20' : 'border-ae-border'}
              `}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono font-bold text-ae-cyan">{msg.agent}</span>
                  <span className="text-[9px] font-mono text-ae-dim">{msg.timestamp}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {msg.approved && <Badge variant="green">approved</Badge>}
                  <Badge variant={actionVariant[msg.action]}>{msg.action}</Badge>
                </div>
              </div>
              <p className="text-[12px] text-ae-muted leading-relaxed">{msg.msg}</p>
              {!msg.approved && (
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={() => approveMessage(msg.id)}
                  className="mt-2 px-2.5 py-1 text-[10px] font-mono border border-ae-green/30 rounded
                    text-ae-green hover:bg-ae-green-dim transition-colors duration-150"
                >
                  Approve →
                </motion.button>
              )}
            </motion.div>
          ))}
        </div>

        <div className="flex gap-2 flex-wrap pt-2 border-t border-ae-border">
          <button
            onClick={approveAll}
            className="px-3 py-1.5 text-[10px] font-mono border border-ae-border rounded text-ae-muted
              hover:border-ae-green/40 hover:text-ae-green transition-colors duration-150"
          >
            Approve all
          </button>
          <button
            className="px-3 py-1.5 text-[10px] font-mono border border-ae-border rounded text-ae-muted
              hover:border-ae-border-bright hover:text-ae-text transition-colors duration-150"
          >
            Repeat all
          </button>
          <button
            className="px-3 py-1.5 text-[10px] font-mono border border-ae-border rounded text-ae-muted
              hover:border-ae-border-bright hover:text-ae-text transition-colors duration-150"
          >
            Optimize
          </button>
        </div>
      </div>
    </div>
  )
}
