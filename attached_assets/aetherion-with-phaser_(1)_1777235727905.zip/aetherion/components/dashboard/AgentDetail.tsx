'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { Agent } from '@/types'
import { Badge } from '@/components/ui/Badge'
import { StatusDot } from '@/components/ui/StatusDot'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { STATUS_COLORS } from '@/lib/data'

interface AgentDetailProps {
  agent: Agent | null
}

const roleColors: Record<string, 'cyan' | 'blue' | 'violet' | 'amber' | 'green'> = {
  Research: 'cyan',
  Strategy: 'blue',
  Builder: 'amber',
  Design: 'violet',
  Growth: 'green',
  Analytics: 'blue',
}

export function AgentDetail({ agent }: AgentDetailProps) {
  return (
    <AnimatePresence mode="wait">
      {agent ? (
        <motion.div
          key={agent.id}
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -8 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="bg-ae-surface border border-ae-border rounded-lg p-4 sticky top-4"
        >
          <div className="text-[9px] font-mono tracking-widest text-ae-muted mb-4">SELECTED AGENT</div>

          {/* Avatar + name */}
          <div className="flex items-center gap-3 mb-4">
            <div className={`
              w-9 h-9 rounded-full flex items-center justify-center
              text-[13px] font-bold font-mono
              bg-ae-blue-dim text-ae-blue border border-ae-blue/30
            `}>
              {agent.initials}
            </div>
            <div>
              <div className="text-sm font-bold text-ae-text">{agent.name}</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Badge variant={roleColors[agent.role] || 'blue'}>{agent.role}</Badge>
                <span className="text-[9px] font-mono text-ae-dim">LV.{agent.level}</span>
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="flex items-center gap-2 mb-3 pb-3 border-b border-ae-border">
            <StatusDot status={agent.status} size="md" />
            <span className={`text-[11px] font-mono ${STATUS_COLORS[agent.status] || 'text-ae-muted'}`}>
              {agent.status}
            </span>
          </div>

          {/* Task */}
          <div className="mb-3">
            <div className="text-[9px] font-mono text-ae-muted tracking-widest mb-1">CURRENT TASK</div>
            <div className="text-[12px] text-ae-text/80 leading-relaxed">{agent.task}</div>
          </div>

          {/* Progress */}
          {agent.pct > 0 && (
            <div className="mb-3">
              <ProgressBar
                value={agent.pct}
                color={roleColors[agent.role] || 'blue'}
                showLabel
              />
            </div>
          )}

          {/* Room */}
          <div className="mb-4 pb-3 border-b border-ae-border">
            <div className="text-[9px] font-mono text-ae-muted tracking-widest mb-1">ROOM</div>
            <div className="text-[12px] text-ae-muted">{agent.room}</div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 flex-wrap">
            {['Upgrade', 'Assign', 'Remove'].map(action => (
              <button
                key={action}
                className="px-2.5 py-1 text-[10px] font-mono border border-ae-border rounded text-ae-muted
                  hover:border-ae-border-bright hover:text-ae-text transition-colors duration-150"
              >
                {action}
              </button>
            ))}
          </div>
        </motion.div>
      ) : (
        <motion.div
          key="empty"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-ae-surface border border-dashed border-ae-border rounded-lg p-4
            flex items-center justify-center min-h-[200px]"
        >
          <p className="text-[11px] font-mono text-ae-dim">Select an agent</p>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
