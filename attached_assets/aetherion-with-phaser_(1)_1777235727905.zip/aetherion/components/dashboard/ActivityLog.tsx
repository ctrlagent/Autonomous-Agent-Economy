'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { LogEntry } from '@/types'
import { useLiveLog } from '@/hooks/useLiveLog'

const typeColor: Record<string, string> = {
  ok: 'text-ae-green',
  info: 'text-ae-blue',
  warn: 'text-ae-amber',
  error: 'text-ae-red',
}

const typePrefix: Record<string, string> = {
  ok: '✓',
  info: '→',
  warn: '⚠',
  error: '✕',
}

export function ActivityLog() {
  const logs = useLiveLog()

  return (
    <div className="bg-ae-surface border border-ae-border rounded-lg p-3 h-full flex flex-col min-h-0">
      <div className="text-[9px] font-mono tracking-widest text-ae-muted mb-3 flex items-center justify-between">
        <span>ACTIVITY LOG</span>
        <span className="text-ae-green/60">● LIVE</span>
      </div>
      <div className="flex-1 overflow-y-auto space-y-0 min-h-0">
        <AnimatePresence initial={false} mode="popLayout">
          {logs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, x: -12, height: 0 }}
              animate={{ opacity: 1, x: 0, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
              className="border-b border-ae-border/50 py-1.5"
            >
              <div className="text-[9px] font-mono text-ae-dim">{log.time}</div>
              <div className={`text-[11px] mt-0.5 ${typeColor[log.type]}`}>
                <span className="mr-1">{typePrefix[log.type]}</span>
                {log.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}
