'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { Room } from '@/types'
import { Badge } from '@/components/ui/Badge'
import { ProgressBar } from '@/components/ui/ProgressBar'

interface RoomDetailProps {
  room: Room | null
}

export function RoomDetail({ room }: RoomDetailProps) {
  return (
    <AnimatePresence mode="wait">
      {room ? (
        <motion.div
          key={room.id}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="bg-ae-surface border border-ae-border rounded-lg p-4"
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base">{room.icon}</span>
                <span className="text-sm font-semibold text-ae-text">{room.name}</span>
                <span className="text-[9px] font-mono text-ae-dim">v1.0</span>
              </div>
            </div>
            <Badge variant={room.status === 'active' ? 'green' : room.status === 'working' ? 'blue' : 'muted'}>
              {room.status.toUpperCase()}
            </Badge>
          </div>

          <div className="flex gap-4 mb-3 font-mono text-[10px] text-ae-muted">
            <span>AGENTS: {room.agents}</span>
            <span>TASKS: {room.tasks.length}</span>
            {room.pct > 0 && <span>PROGRESS: {room.pct}%</span>}
          </div>

          {room.pct > 0 && (
            <div className="mb-3">
              <ProgressBar value={room.pct} color="cyan" showLabel />
            </div>
          )}

          <div className="space-y-1.5 mb-4">
            {room.tasks.length > 0 ? room.tasks.map((task, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-start gap-2 text-[12px] text-ae-muted border-b border-ae-border/50 pb-1.5"
              >
                <span className="text-ae-blue mt-0.5 text-[10px]">→</span>
                {task}
              </motion.div>
            )) : (
              <div className="text-[12px] text-ae-dim">No active tasks</div>
            )}
          </div>

          <div className="flex gap-2 flex-wrap">
            {['Upgrade', 'Pause', 'Re-run'].map(action => (
              <button
                key={action}
                className="px-3 py-1 text-[10px] font-mono border border-ae-border rounded text-ae-muted
                  hover:border-ae-border-bright hover:text-ae-text transition-colors duration-150"
              >
                {action}
              </button>
            ))}
          </div>
        </motion.div>
      ) : (
        <motion.div
          key="empty"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-ae-surface border border-dashed border-ae-border rounded-lg p-4
            flex items-center justify-center h-full min-h-[140px]"
        >
          <p className="text-[11px] font-mono text-ae-dim">Select a room to inspect</p>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
