'use client'
import { motion } from 'framer-motion'
import { Badge } from '@/components/ui/Badge'

interface HeaderProps {
  revenue: number
  taskCount: number
  agentCount: number
}

export function Header({ revenue, taskCount, agentCount }: HeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="flex items-center justify-between flex-wrap gap-4 mb-6"
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <h1 className="text-xl font-black tracking-[0.18em] text-ae-text" style={{ fontFamily: 'var(--font-mono)' }}>
            AETHERION
          </h1>
          <div className="absolute -bottom-0.5 left-0 right-0 h-px bg-gradient-to-r from-ae-cyan via-ae-blue to-transparent" />
        </div>
        <Badge variant="green">ONLINE</Badge>
        <span className="text-[11px] font-mono text-ae-muted hidden sm:block">
          Crypto Developer Station
        </span>
      </div>

      <div className="flex gap-5">
        {[
          { label: 'REVENUE', value: `$${revenue.toLocaleString()}`, color: 'text-ae-green' },
          { label: 'TASKS', value: String(taskCount), color: 'text-ae-blue' },
          { label: 'AGENTS', value: String(agentCount), color: 'text-ae-cyan' },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.07, duration: 0.4 }}
            className="text-right"
          >
            <div className="text-[9px] font-mono tracking-widest text-ae-muted">{stat.label}</div>
            <div className={`text-[15px] font-bold font-mono ${stat.color}`}>{stat.value}</div>
          </motion.div>
        ))}
      </div>
    </motion.header>
  )
}
