'use client'
import { motion } from 'framer-motion'
import { Agent } from '@/types'
import { StatusDot } from '@/components/ui/StatusDot'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { STATUS_COLORS } from '@/lib/data'

interface AgentCardProps {
  agent: Agent
  selected: boolean
  onClick: () => void
  index: number
}

export function AgentCard({ agent, selected, onClick, index }: AgentCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.05, duration: 0.35, ease: 'easeOut' }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`
        p-2.5 rounded-lg border cursor-pointer transition-all duration-200
        ${selected
          ? 'border-ae-blue/50 bg-ae-blue-dim ae-glow-blue'
          : 'border-ae-border bg-ae-surface hover:border-ae-border-bright'
        }
      `}
    >
      <div className="flex justify-between items-start mb-1.5">
        <div className="text-[13px] font-bold text-ae-text">{agent.name}</div>
        <span className="text-[9px] font-mono text-ae-dim border border-ae-border rounded px-1 py-0.5">
          LV.{agent.level}
        </span>
      </div>

      <div className="text-[11px] text-ae-muted mb-2">{agent.role}</div>

      <div className="flex items-center gap-1.5 mb-2">
        <StatusDot status={agent.status} />
        <span className={`text-[9px] font-mono ${STATUS_COLORS[agent.status] || 'text-ae-muted'}`}>
          {agent.status}
        </span>
      </div>

      {agent.pct > 0 && (
        <ProgressBar
          value={agent.pct}
          color={
            agent.status === 'Deploying' ? 'amber' :
            agent.status === 'Writing' ? 'cyan' :
            agent.status === 'Analyzing' ? 'violet' : 'blue'
          }
        />
      )}
    </motion.div>
  )
}
