'use client'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Tab } from '@/types'
import { Header } from './Header'
import { TabNav } from '@/components/ui/TabNav'
import { StationGrid } from './StationGrid'
import { CrewGrid } from './CrewGrid'
import { Missions } from './Missions'
import { ShipComms } from './ShipComms'
import { Marketplace } from './Marketplace'

const TAB_COMPONENTS: Record<Tab, React.ReactNode> = {
  station: <StationGrid />,
  crew: <CrewGrid />,
  missions: <Missions />,
  comms: <ShipComms />,
  market: <Marketplace />,
}

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<Tab>('station')

  return (
    <div className="min-h-screen p-4 md:p-6 max-w-[1200px] mx-auto">
      <Header revenue={3840} taskCount={24} agentCount={8} />

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="mb-4"
      >
        <TabNav active={activeTab} onChange={setActiveTab} />
      </motion.div>

      {/* Horizontal rule */}
      <div className="h-px bg-gradient-to-r from-ae-blue/20 via-ae-border to-transparent mb-4" />

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
        >
          {TAB_COMPONENTS[activeTab]}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
