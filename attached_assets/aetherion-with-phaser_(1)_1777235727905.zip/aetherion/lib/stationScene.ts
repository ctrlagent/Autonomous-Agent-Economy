/// <reference path="../node_modules/phaser/types/phaser.d.ts" />

export interface AgentSprite {
  id: string
  name: string
  role: string
  status: string
  roomId: string
  pct: number
}

export interface RoomZone {
  id: string
  name: string
  icon: string
  status: string
  col: number
  row: number
}

// ─── colour palette matching Tailwind ae- tokens ──────────────────────────────
const C = {
  bg:        0x0a0b0f,
  surface:   0x0f1118,
  border:    0x1e2130,
  borderBrt: 0x2a2f47,
  text:      0xe4e7f0,
  muted:     0x636b8a,
  dim:       0x363d56,
  cyan:      0x4df0d8,
  blue:      0x4d7fff,
  violet:    0x9b6dff,
  amber:     0xffb84d,
  green:     0x4dff9b,
  red:       0xff4d6d,
}

const STATUS_COLOR: Record<string, number> = {
  active:    C.green,
  working:   C.blue,
  idle:      C.dim,
  Working:   C.blue,
  Active:    C.green,
  Idle:      C.dim,
  Deploying: C.amber,
  Writing:   C.cyan,
  Analyzing: C.violet,
}

const ROOMS: RoomZone[] = [
  { id: 'r1', name: 'Research Lab',   icon: '◎', status: 'active',  col: 0, row: 0 },
  { id: 'r2', name: 'Dev Lab',        icon: '⬡', status: 'working', col: 1, row: 0 },
  { id: 'r3', name: 'Design Studio',  icon: '◈', status: 'active',  col: 2, row: 0 },
  { id: 'r4', name: 'Marketing Hub',  icon: '◉', status: 'working', col: 0, row: 1 },
  { id: 'r5', name: 'Ops Center',     icon: '⬢', status: 'idle',    col: 1, row: 1 },
  { id: 'r6', name: 'Analytics',      icon: '◆', status: 'active',  col: 2, row: 1 },
]

const AGENTS: AgentSprite[] = [
  { id: 'a1', name: 'Prism',  role: 'Research',  status: 'Working',   roomId: 'r1', pct: 72 },
  { id: 'a2', name: 'Forge',  role: 'Strategy',  status: 'Working',   roomId: 'r1', pct: 55 },
  { id: 'a3', name: 'Apex',   role: 'Builder',   status: 'Deploying', roomId: 'r2', pct: 45 },
  { id: 'a4', name: 'Pixel',  role: 'Design',    status: 'Working',   roomId: 'r3', pct: 88 },
  { id: 'a5', name: 'Nova',   role: 'Growth',    status: 'Writing',   roomId: 'r4', pct: 30 },
  { id: 'a6', name: 'Echo',   role: 'Growth',    status: 'Idle',      roomId: 'r4', pct: 0  },
  { id: 'a7', name: 'Rose',   role: 'Analytics', status: 'Active',    roomId: 'r6', pct: 91 },
  { id: 'a8', name: 'Cipher', role: 'Analytics', status: 'Analyzing', roomId: 'r6', pct: 78 },
]

// ─── Particle pool (simple gfx objects) ─────────────────────────────────────
interface Particle {
  x: number; y: number
  vx: number; vy: number
  life: number; maxLife: number
  color: number; radius: number
}

// ─── Agent runtime state ─────────────────────────────────────────────────────
interface AgentState {
  data: AgentSprite
  x: number; y: number
  tx: number; ty: number   // target waypoint
  speed: number
  waypointTimer: number
  selected: boolean
  pulsePhase: number
  particles: Particle[]
  trailX: number[]; trailY: number[]
  commTimer: number        // timer for comms line flashes
  commTarget: number | null
}

// ─── The Scene ───────────────────────────────────────────────────────────────
export class StationScene extends Phaser.Scene {
  private gfx!: Phaser.GameObjects.Graphics
  private roomBounds: Map<string, { x: number; y: number; w: number; h: number }> = new Map()
  private agents: AgentState[] = []
  private selectedAgentId: string | null = null
  private scanY = 0
  private gridAlpha = 0
  private frameCount = 0
  public onAgentSelect?: (agent: AgentSprite | null) => void

  constructor() { super({ key: 'StationScene' }) }

  preload() {}

  create() {
    this.gfx = this.add.graphics()

    // compute room bounds
    const { width, height } = this.scale
    const padX = 20, padY = 48
    const cols = 3, rows = 2
    const gap = 8
    const rw = (width  - padX * 2 - gap * (cols - 1)) / cols
    const rh = (height - padY * 2 - gap * (rows - 1)) / rows

    ROOMS.forEach(r => {
      const x = padX + r.col * (rw + gap)
      const y = padY + r.row * (rh + gap)
      this.roomBounds.set(r.id, { x, y, w: rw, h: rh })
    })

    // initialise agents
    AGENTS.forEach(data => {
      const b = this.roomBounds.get(data.roomId)!
      const margin = 28
      const ax = b.x + margin + Math.random() * (b.w - margin * 2)
      const ay = b.y + margin + Math.random() * (b.h - margin * 2)
      this.agents.push({
        data,
        x: ax, y: ay,
        tx: ax, ty: ay,
        speed: data.status === 'Idle' ? 0.4 : 0.8 + Math.random() * 0.6,
        waypointTimer: Math.random() * 120,
        selected: false,
        pulsePhase: Math.random() * Math.PI * 2,
        particles: [],
        trailX: [], trailY: [],
        commTimer: Math.floor(Math.random() * 200 + 80),
        commTarget: null,
      })
    })

    // click / tap to select
    this.input.on('pointerdown', (p: Phaser.Input.Pointer) => {
      let hit: AgentState | null = null
      for (const ag of this.agents) {
        const dist = Phaser.Math.Distance.Between(p.x, p.y, ag.x, ag.y)
        if (dist < 14) { hit = ag; break }
      }
      if (hit) {
        this.agents.forEach(a => a.selected = false)
        if (this.selectedAgentId === hit.data.id) {
          this.selectedAgentId = null
          this.onAgentSelect?.(null)
        } else {
          hit.selected = true
          this.selectedAgentId = hit.data.id
          this.onAgentSelect?.(hit.data)
        }
      } else {
        this.agents.forEach(a => a.selected = false)
        this.selectedAgentId = null
        this.onAgentSelect?.(null)
      }
    })

    // fade-in grid alpha
    this.tweens.add({
      targets: { v: 0 },
      v: 1,
      duration: 1200,
      ease: 'Sine.easeOut',
      onUpdate: (t: Phaser.Tweens.Tween, target: { v: number }) => {
        this.gridAlpha = target.v
      }
    })
  }

  update(_time: number, delta: number) {
    this.frameCount++
    const dt = delta / 16.67   // normalise to ~60fps
    this.gfx.clear()
    this.scanY = (_time / 18) % (this.scale.height + 60)

    this.drawBackground()
    this.drawGrid()
    this.drawRooms()
    this.updateAndDrawCommLines(dt)
    this.updateAndDrawAgents(dt)
    this.drawScanline()
    this.drawTitle()
  }

  // ── Background ─────────────────────────────────────────────────────────────
  private drawBackground() {
    this.gfx.fillStyle(C.bg, 1)
    this.gfx.fillRect(0, 0, this.scale.width, this.scale.height)
  }

  // ── Dot grid ───────────────────────────────────────────────────────────────
  private drawGrid() {
    const spacing = 24
    this.gfx.fillStyle(C.blue, 0.06 * this.gridAlpha)
    for (let x = 0; x < this.scale.width; x += spacing) {
      for (let y = 0; y < this.scale.height; y += spacing) {
        this.gfx.fillRect(x, y, 1, 1)
      }
    }
  }

  // ── Room panels ────────────────────────────────────────────────────────────
  private drawRooms() {
    ROOMS.forEach((r, ri) => {
      const b = this.roomBounds.get(r.id)!
      const col = STATUS_COLOR[r.status] ?? C.dim
      const isActive = r.status !== 'idle'

      // subtle room glow for active
      if (isActive) {
        this.gfx.fillStyle(col, 0.025 * this.gridAlpha)
        this.gfx.fillRoundedRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4, 6)
      }

      // room fill
      this.gfx.fillStyle(C.surface, 0.95)
      this.gfx.fillRoundedRect(b.x, b.y, b.w, b.h, 6)

      // border
      const borderAlpha = isActive ? 0.35 : 0.18
      this.gfx.lineStyle(1, isActive ? col : C.border, borderAlpha * this.gridAlpha)
      this.gfx.strokeRoundedRect(b.x, b.y, b.w, b.h, 6)

      // top-left corner accent
      if (isActive) {
        this.gfx.lineStyle(1.5, col, 0.5 * this.gridAlpha)
        this.gfx.beginPath()
        this.gfx.moveTo(b.x, b.y + 14)
        this.gfx.lineTo(b.x, b.y + 4)
        this.gfx.lineTo(b.x + 10, b.y)
        this.gfx.strokePath()
      }

      // status dot
      const dotPulse = isActive
        ? 0.55 + 0.45 * Math.sin(this.frameCount * 0.06 + ri)
        : 0.3
      this.gfx.fillStyle(col, dotPulse)
      this.gfx.fillCircle(b.x + b.w - 10, b.y + 10, 3)

      // room name  (drawn via Text objects is heavy; use Graphics lines + rely on CSS overlay)
      // We'll draw a small coloured label bar at the bottom instead
      this.gfx.fillStyle(col, 0.06)
      this.gfx.fillRoundedRect(b.x + 6, b.y + b.h - 18, b.w - 12, 10, 3)

      // agent count bar at bottom
      const agentsInRoom = this.agents.filter(a => a.data.roomId === r.id).length
      if (agentsInRoom > 0) {
        const bw = (b.w - 24) * (agentsInRoom / 3)
        this.gfx.fillStyle(col, 0.18)
        this.gfx.fillRect(b.x + 12, b.y + b.h - 15, bw, 3)
      }
    })

    // Draw Text overlays once (room names)
    // Using Phaser Text is heavy so we avoid re-creating; done via CSS overlay in React
  }

  // ── Comm lines (agent-to-agent data flash) ─────────────────────────────────
  private updateAndDrawCommLines(dt: number) {
    this.agents.forEach((ag, idx) => {
      ag.commTimer -= dt
      if (ag.commTimer <= 0) {
        // pick random peer in same or adjacent room
        const peers = this.agents.filter((_, i) => i !== idx)
        ag.commTarget = peers[Math.floor(Math.random() * peers.length)] ? idx : null
        const target = peers[Math.floor(Math.random() * peers.length)]
        if (target && ag.data.status !== 'Idle') {
          // draw flash line
          const col = STATUS_COLOR[ag.data.status] ?? C.blue
          const t = Math.max(0, -ag.commTimer / 12)
          this.gfx.lineStyle(0.5, col, (1 - t) * 0.4)
          this.gfx.beginPath()
          this.gfx.moveTo(ag.x, ag.y)
          this.gfx.lineTo(target.x, target.y)
          this.gfx.strokePath()

          // midpoint dot
          const mx = (ag.x + target.x) / 2
          const my = (ag.y + target.y) / 2
          this.gfx.fillStyle(col, (1 - t) * 0.6)
          this.gfx.fillCircle(mx, my, 1.5)
        }
        if (ag.commTimer < -12) ag.commTimer = Math.floor(Math.random() * 160 + 60)
      }
    })
  }

  // ── Agents ─────────────────────────────────────────────────────────────────
  private updateAndDrawAgents(dt: number) {
    this.agents.forEach(ag => {
      this.updateAgentMovement(ag, dt)
      this.updateAgentParticles(ag, dt)
      this.drawAgentTrail(ag)
      this.drawAgentParticles(ag)
      this.drawAgent(ag)
    })
  }

  private updateAgentMovement(ag: AgentState, dt: number) {
    // countdown to new waypoint
    ag.waypointTimer -= dt
    if (ag.waypointTimer <= 0) {
      const b = this.roomBounds.get(ag.data.roomId)!
      const margin = 26
      ag.tx = b.x + margin + Math.random() * (b.w - margin * 2)
      ag.ty = b.y + margin + Math.random() * (b.h - margin * 2)
      ag.waypointTimer = ag.data.status === 'Idle'
        ? 180 + Math.random() * 120
        : 80  + Math.random() * 80
    }

    // move toward target
    const dx = ag.tx - ag.x
    const dy = ag.ty - ag.y
    const dist = Math.sqrt(dx * dx + dy * dy)
    if (dist > 1) {
      const spd = ag.speed * dt
      const step = Math.min(spd, dist)
      ag.x += (dx / dist) * step
      ag.y += (dy / dist) * step
    }

    // trail
    if (this.frameCount % 3 === 0 && ag.data.status !== 'Idle') {
      ag.trailX.push(ag.x)
      ag.trailY.push(ag.y)
      if (ag.trailX.length > 12) {
        ag.trailX.shift()
        ag.trailY.shift()
      }
    }

    // phase
    ag.pulsePhase += 0.06 * dt
  }

  private updateAgentParticles(ag: AgentState, dt: number) {
    // age existing particles
    ag.particles = ag.particles.filter(p => p.life > 0)
    ag.particles.forEach(p => {
      p.x += p.vx * dt
      p.y += p.vy * dt
      p.vy += 0.02 * dt
      p.life -= dt
    })

    // emit when working hard
    if (ag.data.status !== 'Idle' && Math.random() < 0.12) {
      const col = STATUS_COLOR[ag.data.status] ?? C.blue
      const angle = Math.random() * Math.PI * 2
      const spd = 0.3 + Math.random() * 0.5
      ag.particles.push({
        x: ag.x, y: ag.y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd - 0.2,
        life: 20 + Math.random() * 20,
        maxLife: 40,
        color: col,
        radius: 0.8 + Math.random() * 1,
      })
    }
  }

  private drawAgentTrail(ag: AgentState) {
    if (ag.trailX.length < 2) return
    const col = STATUS_COLOR[ag.data.status] ?? C.blue
    for (let i = 1; i < ag.trailX.length; i++) {
      const alpha = (i / ag.trailX.length) * 0.18
      this.gfx.lineStyle(1, col, alpha)
      this.gfx.beginPath()
      this.gfx.moveTo(ag.trailX[i - 1], ag.trailY[i - 1])
      this.gfx.lineTo(ag.trailX[i], ag.trailY[i])
      this.gfx.strokePath()
    }
  }

  private drawAgentParticles(ag: AgentState) {
    ag.particles.forEach(p => {
      const a = (p.life / p.maxLife) * 0.6
      this.gfx.fillStyle(p.color, a)
      this.gfx.fillCircle(p.x, p.y, p.radius)
    })
  }

  private drawAgent(ag: AgentState) {
    const col = STATUS_COLOR[ag.data.status] ?? C.dim
    const pulse = ag.data.status !== 'Idle'
      ? 0.6 + 0.4 * Math.sin(ag.pulsePhase)
      : 0.3

    // outer glow
    if (ag.data.status !== 'Idle') {
      const glowR = ag.selected ? 16 : 10
      for (let r = glowR; r > 0; r -= 2) {
        this.gfx.fillStyle(col, 0.025 * (1 - r / glowR) * pulse)
        this.gfx.fillCircle(ag.x, ag.y, r)
      }
    }

    // selected ring
    if (ag.selected) {
      const ringPulse = 0.5 + 0.5 * Math.sin(ag.pulsePhase * 1.8)
      this.gfx.lineStyle(1.5, col, 0.8 * ringPulse)
      this.gfx.strokeCircle(ag.x, ag.y, 10)
      // dashes around ring (manual)
      for (let i = 0; i < 8; i++) {
        const a1 = (i / 8) * Math.PI * 2 + this.frameCount * 0.02
        const a2 = a1 + 0.3
        this.gfx.lineStyle(1, col, 0.5)
        this.gfx.beginPath()
        this.gfx.arc(ag.x, ag.y, 14, a1, a2, false)
        this.gfx.strokePath()
      }
    }

    // body
    this.gfx.fillStyle(col, 0.15)
    this.gfx.fillCircle(ag.x, ag.y, 6)

    this.gfx.lineStyle(1.5, col, 0.85 * pulse)
    this.gfx.strokeCircle(ag.x, ag.y, 6)

    // inner dot
    this.gfx.fillStyle(col, 0.9 * pulse)
    this.gfx.fillCircle(ag.x, ag.y, 2.5)
  }

  // ── Scanline ──────────────────────────────────────────────────────────────
  private drawScanline() {
    this.gfx.fillStyle(0xffffff, 0.018)
    this.gfx.fillRect(0, this.scanY - 60, this.scale.width, 60)
    this.gfx.fillStyle(0xffffff, 0.04)
    this.gfx.fillRect(0, this.scanY - 2, this.scale.width, 2)
  }

  // ── HUD title bar ─────────────────────────────────────────────────────────
  private drawTitle() {
    this.gfx.fillStyle(C.blue, 0.06)
    this.gfx.fillRect(0, 0, this.scale.width, 38)
    this.gfx.lineStyle(1, C.blue, 0.15)
    this.gfx.beginPath()
    this.gfx.moveTo(0, 38)
    this.gfx.lineTo(this.scale.width, 38)
    this.gfx.strokePath()
  }

  // ── Public API ────────────────────────────────────────────────────────────
  getRoomBounds(id: string) { return this.roomBounds.get(id) }
  getRooms() { return ROOMS }
}
