import { Room, Agent, Mission, CommMessage, Template, LogEntry } from '@/types'

export const ROOMS: Room[] = [
  { id: 'r1', name: 'Research Lab', icon: '◎', status: 'active', agents: 3, tasks: ['Analyze BTC trend data', 'Competitor landscape scan', 'Sentiment analysis'], pct: 72 },
  { id: 'r2', name: 'Dev Lab', icon: '⬡', status: 'working', agents: 2, tasks: ['Deploy ERC-20 contract', 'Run security tests', 'Configure devnet'], pct: 45 },
  { id: 'r3', name: 'Design Studio', icon: '◈', status: 'active', agents: 1, tasks: ['Brand identity package', 'Token icon set'], pct: 88 },
  { id: 'r4', name: 'Marketing Hub', icon: '◉', status: 'working', agents: 2, tasks: ['Draft viral X thread', 'Schedule 14-day content'], pct: 30 },
  { id: 'r5', name: 'Ops Center', icon: '⬢', status: 'idle', agents: 1, tasks: [], pct: 0 },
  { id: 'r6', name: 'Analytics', icon: '◆', status: 'active', agents: 2, tasks: ['Revenue dashboard', 'KPI tracking', 'Holder distribution'], pct: 91 },
]

export const AGENTS: Agent[] = [
  { id: 'a1', name: 'Prism', role: 'Research', level: 3, status: 'Working', task: 'Scanning BTC trend data across 12 sources', pct: 72, room: 'Research Lab', initials: 'PR' },
  { id: 'a2', name: 'Forge', role: 'Strategy', level: 4, status: 'Working', task: 'Building 48-hour token launch plan', pct: 55, room: 'Research Lab', initials: 'FG' },
  { id: 'a3', name: 'Apex', role: 'Builder', level: 3, status: 'Deploying', task: 'Compiling ERC-20 smart contract bytecode', pct: 45, room: 'Dev Lab', initials: 'AX' },
  { id: 'a4', name: 'Pixel', role: 'Design', level: 2, status: 'Working', task: 'Creating brand identity assets', pct: 88, room: 'Design Studio', initials: 'PX' },
  { id: 'a5', name: 'Nova', role: 'Growth', level: 3, status: 'Writing', task: 'Drafting 3 viral X thread variants', pct: 30, room: 'Marketing Hub', initials: 'NV' },
  { id: 'a6', name: 'Echo', role: 'Growth', level: 2, status: 'Idle', task: 'Awaiting task assignment', pct: 0, room: 'Marketing Hub', initials: 'EC' },
  { id: 'a7', name: 'Rose', role: 'Analytics', level: 3, status: 'Active', task: 'Generating live KPI report', pct: 91, room: 'Analytics', initials: 'RS' },
  { id: 'a8', name: 'Cipher', role: 'Analytics', level: 2, status: 'Analyzing', task: 'Holder distribution analysis', pct: 78, room: 'Analytics', initials: 'CI' },
]

export const MISSIONS: Mission[] = [
  { id: 'm1', name: 'Reach $5,000 Revenue', target: 5000, current: 3840, prefix: '$', reward: '+500 XP' },
  { id: 'm2', name: 'Launch 10 Products', target: 10, current: 7, prefix: '', reward: 'Agent Unlock' },
  { id: 'm3', name: 'Get 1,000 Users', target: 1000, current: 342, prefix: '', reward: 'Commander Badge' },
  { id: 'm4', name: 'Deploy 3 Contracts', target: 3, current: 1, prefix: '', reward: '+200 XP' },
]

export const COMMS: CommMessage[] = [
  { id: 'c1', agent: 'Forge', msg: 'Strategy complete. Launch window identified: next 48h optimal. High sentiment, low competition.', action: 'approve', timestamp: '12:42' },
  { id: 'c2', agent: 'Apex', msg: 'Contract compiled. Reentrancy check passed. Recommend external audit before mainnet deploy.', action: 'review', timestamp: '12:38' },
  { id: 'c3', agent: 'Pixel', msg: 'Brand assets completed — logo, token icon, banner. Ready for deployment package.', action: 'approve', timestamp: '12:31' },
  { id: 'c4', agent: 'Nova', msg: '3 viral X thread variants ready. Variant B has highest projected engagement score (94/100).', action: 'approve', timestamp: '12:20' },
]

export const TEMPLATES: Template[] = [
  { id: 't1', name: 'Crypto Developer', agents: 12, rooms: 6, desc: 'Build & launch token automatically — from research to marketing', rating: 4.8, users: 2340, active: true, category: 'Crypto' },
  { id: 't2', name: 'TikTok Affiliate', agents: 8, rooms: 4, desc: 'Automate affiliate content pipeline at scale', rating: 4.6, users: 1870, active: false, category: 'Content' },
  { id: 't3', name: 'E-Commerce AI', agents: 10, rooms: 5, desc: 'Full store automation — listings, support, analytics', rating: 4.7, users: 3120, active: false, category: 'E-Commerce' },
  { id: 't4', name: 'SaaS Builder', agents: 9, rooms: 5, desc: 'Idea to launch, end-to-end automated', rating: 4.5, users: 890, active: false, category: 'SaaS' },
]

export const INITIAL_LOGS: LogEntry[] = [
  { id: 'l1', time: '12:42', text: 'Forge: Launch plan finalized', type: 'ok' },
  { id: 'l2', time: '12:38', text: 'Apex: Contract compiled', type: 'ok' },
  { id: 'l3', time: '12:31', text: 'Prism: Trend data updated', type: 'info' },
  { id: 'l4', time: '12:20', text: 'Nova: X thread drafted', type: 'info' },
  { id: 'l5', time: '12:05', text: 'Revenue +$320 recorded', type: 'ok' },
  { id: 'l6', time: '11:58', text: 'Pixel: Assets complete', type: 'ok' },
  { id: 'l7', time: '11:44', text: 'Echo: Awaiting task', type: 'warn' },
]

export const LIVE_LOGS: LogEntry[] = [
  { id: 'll1', time: '12:45', text: 'Forge: Tokenomics locked', type: 'ok' },
  { id: 'll2', time: '12:47', text: 'Apex: Deploying to devnet', type: 'info' },
  { id: 'll3', time: '12:51', text: 'Revenue: +$80 incoming', type: 'ok' },
  { id: 'll4', time: '12:56', text: 'Rose: KPI spike detected', type: 'warn' },
  { id: 'll5', time: '13:01', text: 'Nova: Thread published — 847 impressions', type: 'ok' },
]

export const STATUS_COLORS: Record<string, string> = {
  active: 'text-ae-green',
  working: 'text-ae-blue',
  idle: 'text-ae-dim',
  offline: 'text-ae-red',
  Working: 'text-ae-blue',
  Active: 'text-ae-green',
  Idle: 'text-ae-dim',
  Deploying: 'text-ae-amber',
  Writing: 'text-ae-cyan',
  Analyzing: 'text-ae-violet',
}

export const STATUS_BG: Record<string, string> = {
  active: 'bg-ae-green',
  working: 'bg-ae-blue',
  idle: 'bg-ae-dim',
  offline: 'bg-ae-red',
  Working: 'bg-ae-blue',
  Active: 'bg-ae-green',
  Idle: 'bg-ae-dim',
  Deploying: 'bg-ae-amber',
  Writing: 'bg-ae-cyan',
  Analyzing: 'bg-ae-violet',
}
