export type RoomStatus = 'active' | 'working' | 'idle' | 'offline'
export type AgentStatus = 'Working' | 'Active' | 'Idle' | 'Deploying' | 'Writing' | 'Analyzing'
export type LogType = 'ok' | 'info' | 'warn' | 'error'
export type Tab = 'station' | 'crew' | 'missions' | 'comms' | 'market'

export interface Room {
  id: string
  name: string
  icon: string
  status: RoomStatus
  agents: number
  tasks: string[]
  pct: number
}

export interface Agent {
  id: string
  name: string
  role: string
  level: number
  status: AgentStatus
  task: string
  pct: number
  room: string
  initials: string
}

export interface Mission {
  id: string
  name: string
  target: number
  current: number
  prefix: string
  reward: string
}

export interface CommMessage {
  id: string
  agent: string
  msg: string
  action: 'approve' | 'review' | 'optimize'
  timestamp: string
  approved?: boolean
}

export interface Template {
  id: string
  name: string
  agents: number
  rooms: number
  desc: string
  rating: number
  users: number
  active: boolean
  category: string
}

export interface LogEntry {
  id: string
  time: string
  text: string
  type: LogType
}
