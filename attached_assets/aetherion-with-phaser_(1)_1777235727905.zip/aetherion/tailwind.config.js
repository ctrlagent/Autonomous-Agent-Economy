/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        mono: ['var(--font-mono)', 'ui-monospace', 'monospace'],
      },
      colors: {
        ae: {
          bg: '#0a0b0f',
          surface: '#0f1118',
          border: '#1e2130',
          'border-bright': '#2a2f47',
          text: '#e4e7f0',
          muted: '#636b8a',
          dim: '#363d56',
          cyan: '#4df0d8',
          'cyan-dim': '#1a3d39',
          blue: '#4d7fff',
          'blue-dim': '#1a2a4a',
          violet: '#9b6dff',
          'violet-dim': '#2a1a4a',
          amber: '#ffb84d',
          'amber-dim': '#3d2a0d',
          green: '#4dff9b',
          'green-dim': '#0d3a1e',
          red: '#ff4d6d',
          'red-dim': '#3a0d18',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scanline': 'scanline 8s linear infinite',
        'float': 'float 4s ease-in-out infinite',
      },
      keyframes: {
        scanline: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-4px)' },
        },
      },
    },
  },
  plugins: [],
}
