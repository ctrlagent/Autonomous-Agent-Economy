'use client'
import { useState, useEffect } from 'react'
import { LogEntry } from '@/types'
import { INITIAL_LOGS, LIVE_LOGS } from '@/lib/data'

export function useLiveLog() {
  const [logs, setLogs] = useState<LogEntry[]>(INITIAL_LOGS)
  const [liveIdx, setLiveIdx] = useState(0)

  useEffect(() => {
    if (liveIdx >= LIVE_LOGS.length) return
    const t = setTimeout(() => {
      setLogs(prev => [LIVE_LOGS[liveIdx], ...prev].slice(0, 9))
      setLiveIdx(i => i + 1)
    }, 4500 + liveIdx * 500)
    return () => clearTimeout(t)
  }, [liveIdx])

  return logs
}
